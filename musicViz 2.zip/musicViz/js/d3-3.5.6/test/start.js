var d3 = {version: "0.0.1"}; // semver
